declare module 'video.js';
